import React from 'react';

class ShowBookings extends React.Component {
    constructor(){
        super();
        this.state = {
            data:[],
            queryString:'',
            searchedData:[]
        }
    }
    //1. fetch data form the https://localhost:3000/data/data.json and store in data state
    //2. handleChange to store the form data in searchQuery state
    //3. handleSearch
        // search the respective object from data state and store in searchedData state 
    
    render() {
        //generate array of tr containing five td for each column
        //please see the table given in the image for reference
        
        return (
            <div>
                {/*Generate the UI as shown in the image*/}
            </div>
        )
    }
}
export default ShowBookings;