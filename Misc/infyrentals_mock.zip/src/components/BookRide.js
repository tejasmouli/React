import React from 'react';

class BookRide extends React.Component {
    constructor(){
        super();
        this.state = {
            fleet:[ 
                {vId: "V1001", vName:"Bajaj Vikrant", rent:400},
                {vId: "V1002", vName:"Honda Dio", rent: 200},
                {vId: "V1003", vName:"Hero Xtreme", rent: 450},
                {vId: "V1004", vName:"Royal Enfield Thunderbird", rent: 500},
                {vId: "V1005", vName:"TVS Apache", rent: 300},
                ],
            //add the states with proper initial values
            
            
        }
    }
    //1. handleChange
    /*
    set the form input field values to the respective states
    reset message state and cMessage state
     */
    //2. handleCheck
    /*
    set isChecked state ,
    reset cMessage
     */
    //3. handleSubmit
    /*
    prevent default action of form
    check the question paper for detailed validation information
    */

    render() {
       // find the bike object having vId same as the route parameter fleetCode 
        
        //calculate total rent, based on number of days and rent per day
        //calculate no of days by using date object's properties
       
        

        return (
            <div>
                {/* generate the UI as shown in the image */}
            </div>
        )
        
    }
}
export default BookRide;