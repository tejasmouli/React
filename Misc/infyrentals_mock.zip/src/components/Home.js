import React from 'react';
import { Link } from 'react-router-dom';

class Home extends React.Component {
    constructor(){
        super();
        this.state = {
            fleet:[ 
                {vId: "V1001", vName:"Bajaj Vikrant", rent:400},
                {vId: "V1002", vName:"Honda Dio", rent: 200},
                {vId: "V1003", vName:"Hero Xtreme", rent: 450},
                {vId: "V1004", vName:"Royal Enfield Thunderbird", rent: 500},
                {vId: "V1005", vName:"TVS Apache", rent: 300},
                ]
        }
    }

    render() {
        /*Generate listItems, which should be an array of <li></li> containing Link components
        Link components should navigate to localhost:3000/bookRide/vId
        Vehicle names should be Route Links
        */
        
        return (
            <div>
                {/* Generate the UI as shown in the image*/}
                
            </div>
        )
    }
}
export default Home;