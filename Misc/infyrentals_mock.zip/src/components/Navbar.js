import React from 'react';
import { Nav, Navbar } from 'react-bootstrap';
import { Link } from 'react-router-dom'


const Navigation = () => {
        return (
            <Navbar bg="primary" variant="dark" >
                <Navbar.Brand><Link className="text text-white" to="/">Infy Rentals</Link></Navbar.Brand>
                <Nav className="mr-auto">
                    {/*Create Links to navigate to '/home' and '/showBookings'. Refer to the Navigation bar in the image for reference*/}
                </Nav>
            </Navbar>
        )
    
}
export default Navigation;
