import React from 'react';
import Navigation from './components/Navbar';
import './App.css';
import { BrowserRouter, Route } from 'react-router-dom';
import Home from './components/Home';
import BookRide from './components/BookRide';
import ShowBookings from './components/ShowBookings';

function App() {
  return (
      <div className="App">
        <BrowserRouter>
          <Navigation />
          {/* Render the components according to the route paths and parameters(s)
		  */}
        </BrowserRouter>
      </div>
  );
}

export default App;
